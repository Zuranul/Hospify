<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="refresh" content="5" >
    <link rel="stylesheet" type="text/css" href="style.css" media="screen"/>

    <title> GPS Tracker Data </title>

</head>

<body>

    <h1>GPS Tracker Mobile Application Log</h1>
<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "project2";

// Create connection
$link = new mysqli($host, $username, $password, $dbname);
// Check connection
if ($link->connect_error) {
    die("Connection failed: " . $link->connect_error);
}

$sql = "SELECT profileName, email, ip_address, user_agent, latitude, longitude, address, timestamp FROM users ORDER BY timestamp DESC"; /*select data to display from the users table in the data base*/

echo '<table cellspacing="5" cellpadding="5">
      <tr> 
        <th>PROFILE NAME</th> 
        <th>EMAIL</th>  
        <th>IP ADDRESS</th>     
        <th>USER AGENT</th> 
        <th>ADDRESS</th> 
        <th>LATITUDE</th> 
        <th>LONGITUDE</th> 
        <th>TIMESTAMP</th> 
      </tr>';
 
if ($result = $link->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $profileName = $row["profileName"];
        $email = $row["email"];
        $ipaddress = $row["ip_address"];
        $useragent = $row["user_agent"];
        $address = $row["address"];
        $latitude = $row["latitude"];
        $longitude = $row["longitude"];
        $timestamp = $row["timestamp"];

        // Uncomment to set timezone to - 1 hour (you can change 1 to any number)
       // $row_reading_time = date("Y-m-d H:i:s", strtotime("$row_reading_time - 1 hours"));
      
        // Uncomment to set timezone to + 4 hours (you can change 4 to any number)
        //$row_reading_time = date("Y-m-d H:i:s", strtotime("$row_reading_time + 4 hours"));
      
        echo '<tr> 
                <td>' . $profileName . '</td> 
                <td>' . $email . '</td> 
                <td>' . $ipaddress. '</td> 
                <td>' . $useragent. '</td> 
                <td>' . $address. '</td> 
                <td>' . $latitude. '</td> 
                <td>' . $longitude. '</td> 
                <td>' . $timestamp. '</td> 
              </tr>';
    }
    $result->free();
}
$link->close();
?> 
</table>

</body>
</html>

    </body>
</html>