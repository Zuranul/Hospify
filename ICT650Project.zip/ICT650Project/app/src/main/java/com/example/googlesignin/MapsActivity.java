package com.example.googlesignin;


import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.CheckBox;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;


import com.example.googlesignin.databinding.ActivityMapsBinding;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Vector;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    MarkerOptions marker;
    Vector<MarkerOptions> markerOptions;

    private UiSettings mUiSettings;

    private CheckBox mMyLocationButtonCheckbox;

    private CheckBox mMyLocationLayerCheckbox;

    LatLng kajang;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        markerOptions = new Vector<>();
        markerOptions.add(new MarkerOptions()
                .position(new LatLng(2.992219556845204, 101.79173887282732))
                .title("Hospital Kajang")
                .snippet("Visiting Hours: 12.00PM - 2.00PM")
        );

        markerOptions.add(new MarkerOptions()
                .position(new LatLng(2.9979195009636537, 101.78603113188026))
                .title("Kajang Medical Centre Sdn. Bhd.")
                .snippet("Visiting Hours: 12.00PM - 2.00PM")
        );

        markerOptions.add(new MarkerOptions()
                .position(new LatLng(2.9957980966550894, 101.78828418757743))
                .title("Poliklinik Ideal Sdn. Bhd.")
                .snippet("Operating Hours: 8.00AM - 11.00PM")
        );
        markerOptions.add(new MarkerOptions()
                .position(new LatLng(3.0041060546161473, 101.78670984421662))
                .title("Klinik Thaqif Kajang")
                .snippet("Operating Hours: 9.00AM - 6.00PM")
        );

        markerOptions.add(new MarkerOptions()
                .position(new LatLng(2.9787388415296965, 101.77267172823782))
                .title("Klinik Mediviron")
                .snippet("Operating Hours: 9.00AM - 9.00PM")
        );

        markerOptions.add(new MarkerOptions()
                .position(new LatLng(2.9749329347442623, 101.7800808698556))
                .title("Poliklinik Abdul Rahman")
                .snippet("Operating Hours: 9.00AM - 9.00PM")
        );

        markerOptions.add(new MarkerOptions()
                .position(new LatLng(2.990320868903683, 101.80041824316409))
                .title("Klinik Lee Wee Teck Sdn. Bhd.")
                .snippet("Operating Hours: 9.00AM - 9.30PM")
        );

        markerOptions.add(new MarkerOptions()
                .position(new LatLng(3.000410889932517, 101.78564464111093))
                .title("KPJ Specialist Kajang")
                .snippet("Visiting Hours: 12.00PM - 2.00PM")
        );

        markerOptions.add(new MarkerOptions()
                .position(new LatLng(3.031747117858356, 101.76301082383031))
                .title("Columbia Asia Hospital")
                .snippet("Visiting Hours: 12.00PM - 2.00PM")
        );

        markerOptions.add(new MarkerOptions()
                .position(new LatLng(2.9897544552059214, 101.79122367033696))
                .title("Poliklinik Mediprima")
                .snippet("Operating Hours: 8.00AM - 9.00PM")
        );

        markerOptions.add(new MarkerOptions()
                .position(new LatLng(2.9930821064019737, 101.78452540242301))
                .title("Klinik Hidup Sihat")
                .snippet("Operating Hours: 9.00AM - 7.00PM")
        );

        markerOptions.add(new MarkerOptions()
                .position(new LatLng(2.993030890011908, 101.78840712040201))
                .title("Klinik Mega")
                .snippet("Operating Hours: 9.00AM - 7.00PM")
        );

        markerOptions.add(new MarkerOptions()
                .position(new LatLng(2.9853131621399536, 101.78052772531603))
                .title("Qualitas Health Klinik Era Medik")
                .snippet("Operating Hours: 9.00AM - 8.00PM")
        );

        markerOptions.add(new MarkerOptions()
                .position(new LatLng(2.959997110624598, 101.754163171054))
                .title("Hospital Islam Az-Zahrah")
                .snippet("Visiting Hours: 11.30PM - 3.00PM")
        );

        kajang = new LatLng(2.9913818537436416, 101.76833879431878);
        marker = new MarkerOptions().position(kajang).title("Kajang").snippet("Nearby Hospital");




    }

    private boolean isChecked(int id) {
        return ((CheckBox) findViewById(id)).isChecked();
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;


        // Add a marker in Sydney and move the camera

        //mMap.addMarker(marker);

        for (MarkerOptions mark : markerOptions){
            mMap.addMarker(mark);
        }

        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setZoomGesturesEnabled(true);

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(kajang,8));
        enableMyLocation();

    }

    private void enableMyLocation() {

        String perms[] = {"android.permission.ACCESS_FINE_LOCATION","android.permission.ACCESS_NETWORK_STATE"};
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            if (mMap != null) {
                mMap.setMyLocationEnabled(true);
                Log.d("luqmanul","permission granted");
            }
        } else {
            // Permission to access the location is missing. Show rationale and request permission

            Log.d("luqmanul","permission denied");
            ActivityCompat.requestPermissions(this,perms ,200);

        }
    }


}